﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FinalAssessment.Models;

namespace FinalAssessment.Data
{
    public class MvcMovieContext : DbContext
    {
        public MvcMovieContext(DbContextOptions<MvcMovieContext> options)
            : base(options)
        {
        }

        public DbSet<FinalAssessment.Models.Claim> Claim { get; set; }
        public DbSet<FinalAssessment.Models.Vehicle> Vehicle { get; set; }
        public DbSet<FinalAssessment.Models.Claim> Owner { get; set; }
    }
}
