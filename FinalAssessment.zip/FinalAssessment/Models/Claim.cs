using System.ComponentModel.DataAnnotations;

namespace FinalAssessment.Models
{
    public class Claim
    {
        public int Id { get; set; }
        public string? Descripcion { get; set; }

        public string? Status { get; set; }
        public DateTime Date { get; set; }

        public Vehicle vehicle { get; set; }
    }
}