﻿using FinalAssessment.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace FinalAssessment.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        
        //Esto para enseñar todo
        public IActionResult ShowAllData()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}